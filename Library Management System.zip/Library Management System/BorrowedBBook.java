import java.time.LocalDate;

class BorrowedBook {
    private String memberId;
    private String bookTitle;
    private LocalDate borrowDate;
    private LocalDate returnDate;

    public BorrowedBook(String memberId, String bookTitle, LocalDate borrowDate, LocalDate returnDate) {
        this.memberId = memberId;
        this.bookTitle = bookTitle;
        this.borrowDate = borrowDate;
        this.returnDate = returnDate;
    }

    @Override
    public String toString() {
        return "Member ID: " + memberId + ", Book: " + bookTitle + ", Borrow Date: " + borrowDate + ", Return Date: " + returnDate;
    }
}
