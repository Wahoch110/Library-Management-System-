import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

class Library {
    public List<Book> books = new ArrayList<>();
    private List<Member> members = new ArrayList<>();
    private List<BorrowedBook> borrowedBooks = new ArrayList<>();

    public void addBook(Book book) {
        books.add(book);
    }

    public void addMember(Member member) {
        members.add(member);
    }

    public Book searchBookByTitle(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    public Member searchMemberById(String id) {
        for (Member member : members) {
            if (member.getId().equals(id)) {
                return member;
            }
        }
        return null;
    }

    public void addBorrowedBookRecord(String memberId, String bookTitle, int days) {
        LocalDate borrowDate = LocalDate.now();
        LocalDate returnDate = borrowDate.plusDays(days);
        borrowedBooks.add(new BorrowedBook(memberId, bookTitle, borrowDate, returnDate));
    }

    public List<BorrowedBook> getBorrowedBooks() {
        return borrowedBooks;
    }
}


public class LibraryManagementSystem extends JFrame {
    private Library library = new Library();

    public LibraryManagementSystem() {
        setTitle("Library Management System");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTabbedPane tabbedPane = new JTabbedPane();

        tabbedPane.add("Manage Books", createManageBooksPanel());
        tabbedPane.add("Manage Members", createManageMembersPanel());
        tabbedPane.add("View Books", createViewBooksPanel());
        tabbedPane.add("Borrow Book", createBorrowBookPanel());
        tabbedPane.add("Borrowed Books", createBorrowedBooksPanel());

        add(tabbedPane);
    }

    private JPanel createManageBooksPanel() {
        JPanel panel = new JPanel(new GridLayout(5, 2));

        JLabel lblTitle = new JLabel("Title:");
        JTextField txtTitle = new JTextField();

        JLabel lblAuthor = new JLabel("Author:");
        JTextField txtAuthor = new JTextField();

        JLabel lblCopies = new JLabel("Copies:");
        JTextField txtCopies = new JTextField();

        JButton btnAddBook = new JButton("Add Book");
        btnAddBook.addActionListener(e -> {
            String title = txtTitle.getText();
            String author = txtAuthor.getText();
            int copies = Integer.parseInt(txtCopies.getText());
            library.addBook(new Book(title, author, copies));
            JOptionPane.showMessageDialog(this, "Book added successfully!");
        });

        panel.add(lblTitle);
        panel.add(txtTitle);
        panel.add(lblAuthor);
        panel.add(txtAuthor);
        panel.add(lblCopies);
        panel.add(txtCopies);
        panel.add(new JLabel());
        panel.add(btnAddBook);

        return panel;
    }

    private JPanel createManageMembersPanel() {
        JPanel panel = new JPanel(new GridLayout(4, 2));

        JLabel lblId = new JLabel("ID:");
        JTextField txtId = new JTextField();

        JLabel lblName = new JLabel("Name:");
        JTextField txtName = new JTextField();

        JLabel lblPassword = new JLabel("Password:");
        JPasswordField txtPassword = new JPasswordField();

        JButton btnAddMember = new JButton("Add Member");
        btnAddMember.addActionListener(e -> {
            String id = txtId.getText();
            String name = txtName.getText();
            String password = new String(txtPassword.getPassword());
            library.addMember(new Member(id, name, password));
            JOptionPane.showMessageDialog(this, "Member added successfully!");
        });

        panel.add(lblId);
        panel.add(txtId);
        panel.add(lblName);
        panel.add(txtName);
        panel.add(lblPassword);
        panel.add(txtPassword);
        panel.add(new JLabel());
        panel.add(btnAddMember);

        return panel;
    }

    private JPanel createViewBooksPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        JButton btnViewBooks = new JButton("View Books");
        btnViewBooks.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            for (Book book : library.books) {
                sb.append(book).append("\n");
            }
            textArea.setText(sb.toString());
        });

        panel.add(new JScrollPane(textArea), BorderLayout.CENTER);
        panel.add(btnViewBooks, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createBorrowBookPanel() {
        JPanel panel = new JPanel(new GridLayout(6, 2));

        JLabel lblMemberID = new JLabel("Member ID:");
        JTextField txtMemberID = new JTextField();

        JLabel lblPassword = new JLabel("Password:");
        JPasswordField txtPassword = new JPasswordField();

        JLabel lblBookTitle = new JLabel("Book Title:");
        JTextField txtBookTitle = new JTextField();

        JLabel lblDays = new JLabel("Number of Days (Default: 10):");
        JTextField txtDays = new JTextField();

        JButton btnBorrow = new JButton("Borrow Book");
        btnBorrow.addActionListener(e -> {
            String memberID = txtMemberID.getText();
            String password = new String(txtPassword.getPassword());
            String bookTitle = txtBookTitle.getText();
            int days = txtDays.getText().isEmpty() ? 10 : Integer.parseInt(txtDays.getText());

            Member member = library.searchMemberById(memberID);
            if (member == null || !member.getPassword().equals(password)) {
                JOptionPane.showMessageDialog(this, "Invalid Member ID or Password!");
                return;
            }

            Book book = library.searchBookByTitle(bookTitle);
            if (book == null || book.getCopies() <= 0) {
                JOptionPane.showMessageDialog(this, "Book not available!");
                return;
            }

            book.setCopies(book.getCopies() - 1);
            library.addBorrowedBookRecord(memberID, bookTitle, days);
            JOptionPane.showMessageDialog(this, "Book borrowed successfully!");
        });

        panel.add(lblMemberID);
        panel.add(txtMemberID);
        panel.add(lblPassword);
        panel.add(txtPassword);
        panel.add(lblBookTitle);
        panel.add(txtBookTitle);
        panel.add(lblDays);
        panel.add(txtDays);
        panel.add(new JLabel());
        panel.add(btnBorrow);

        return panel;
    }

    private JPanel createBorrowedBooksPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        JButton btnViewBorrowed = new JButton("View Borrowed Books");
        btnViewBorrowed.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            for (BorrowedBook record : library.getBorrowedBooks()) {
                sb.append(record).append("\n");
            }
            textArea.setText(sb.toString());
        });

        panel.add(new JScrollPane(textArea), BorderLayout.CENTER);
        panel.add(btnViewBorrowed, BorderLayout.SOUTH);

        return panel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LibraryManagementSystem().setVisible(true));
    }
}
